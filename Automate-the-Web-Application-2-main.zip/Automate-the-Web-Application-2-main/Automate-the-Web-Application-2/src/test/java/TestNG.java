import org.testng.annotations.Test;

public class TestNG {
  @Test
  public void f() {
  }
}
